// ZaRemba AI Watcher – signed threat feed.
//
// The research team publishes intel/threats.json in the official repository,
// signed with the ZaRemba intel key (minisign, Ed25519 over a BLAKE2b-512
// hash). The extension downloads it, verifies the signature against the key
// below and the quality rules, and only then uses its browser_extension
// entries. Anything that fails is ignored and the built-in list stays in use.
"use strict";

(() => {
  const FEED_URL = "https://raw.githubusercontent.com/kayzaa/ZaRemba-AI-Watcher-Official/main/intel/threats.json";
  // Same key as the desktop app (crates/zaremba-intel INTEL_PUBKEY).
  const PUBKEY = "RWRmwsU/vYrD1+SS1u4SADs5OTIXq+rrq1XzAJo9mgMJPUahM9BDfl6l";
  const MAX_BYTES = 5 * 1024 * 1024;

  // ------------------------------------------------------------ BLAKE2b --
  const M64 = (1n << 64n) - 1n;
  const IV = [
    0x6a09e667f3bcc908n, 0xbb67ae8584caa73bn, 0x3c6ef372fe94f82bn, 0xa54ff53a5f1d36f1n,
    0x510e527fade682d1n, 0x9b05688c2b3e6c1fn, 0x1f83d9abfb41bd6bn, 0x5be0cd19137e2179n,
  ];
  const SIGMA = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3],
    [11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4],
    [7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8],
    [9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13],
    [2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9],
    [12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11],
    [13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10],
    [6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5],
    [10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0],
  ];
  const rotr = (x, n) => ((x >> n) | (x << (64n - n))) & M64;

  function compress(h, block, t, last) {
    const m = [];
    for (let i = 0; i < 16; i++) {
      let w = 0n;
      for (let b = 7; b >= 0; b--) w = (w << 8n) | BigInt(block[i * 8 + b]);
      m.push(w);
    }
    const v = [...h, ...IV];
    v[12] ^= t & M64;
    v[13] ^= t >> 64n;
    if (last) v[14] ^= M64;
    const g = (a, b, c, d, x, y) => {
      v[a] = (v[a] + v[b] + x) & M64; v[d] = rotr(v[d] ^ v[a], 32n);
      v[c] = (v[c] + v[d]) & M64; v[b] = rotr(v[b] ^ v[c], 24n);
      v[a] = (v[a] + v[b] + y) & M64; v[d] = rotr(v[d] ^ v[a], 16n);
      v[c] = (v[c] + v[d]) & M64; v[b] = rotr(v[b] ^ v[c], 63n);
    };
    for (let r = 0; r < 12; r++) {
      const s = SIGMA[r % 10];
      g(0, 4, 8, 12, m[s[0]], m[s[1]]); g(1, 5, 9, 13, m[s[2]], m[s[3]]);
      g(2, 6, 10, 14, m[s[4]], m[s[5]]); g(3, 7, 11, 15, m[s[6]], m[s[7]]);
      g(0, 5, 10, 15, m[s[8]], m[s[9]]); g(1, 6, 11, 12, m[s[10]], m[s[11]]);
      g(2, 7, 8, 13, m[s[12]], m[s[13]]); g(3, 4, 9, 14, m[s[14]], m[s[15]]);
    }
    for (let i = 0; i < 8; i++) h[i] ^= v[i] ^ v[i + 8];
  }

  /** BLAKE2b-512 of `data` (Uint8Array), no key. */
  function blake2b512(data) {
    const h = [...IV];
    h[0] ^= 0x01010040n; // digest length 64, no key, fanout 1, depth 1
    const blocks = Math.max(1, Math.ceil(data.length / 128));
    for (let i = 0; i < blocks; i++) {
      const last = i === blocks - 1;
      const block = new Uint8Array(128);
      block.set(data.subarray(i * 128, i * 128 + 128));
      compress(h, block, BigInt(last ? data.length : (i + 1) * 128), last);
    }
    const out = new Uint8Array(64);
    h.forEach((w, i) => { for (let b = 0; b < 8; b++) out[i * 8 + b] = Number((w >> BigInt(8 * b)) & 0xffn); });
    return out;
  }

  // ----------------------------------------------------------- minisign --
  const b64 = (s) => Uint8Array.from(atob(s.replace(/\s+/g, "")), (c) => c.charCodeAt(0));
  const same = (a, b) => a.length === b.length && a.every((x, i) => x === b[i]);

  /** True if `sigFile` is a valid signature of `data` by PUBKEY (prehashed "ED"). */
  async function verify(data, sigFile, pubkey = PUBKEY) {
    try {
      let text = sigFile.trim();
      if (!text.startsWith("untrusted comment:")) text = new TextDecoder().decode(b64(text)); // tauri signer wraps it in base64
      const lines = text.split(/\r?\n/);
      const pk = b64(pubkey);
      const sig = b64(lines[1]);
      const trusted = lines[2]?.startsWith("trusted comment: ") ? lines[2].slice("trusted comment: ".length) : null;
      const globalSig = b64(lines[3] || "");
      if (pk.length !== 42 || sig.length !== 74 || globalSig.length !== 64 || trusted === null) return false;
      if (String.fromCharCode(sig[0], sig[1]) !== "ED" || !same(sig.subarray(2, 10), pk.subarray(2, 10))) return false;
      const key = await crypto.subtle.importKey("raw", pk.subarray(10), { name: "Ed25519" }, false, ["verify"]);
      const okData = await crypto.subtle.verify({ name: "Ed25519" }, key, sig.subarray(10), blake2b512(data));
      const tc = new TextEncoder().encode(trusted);
      const signed = new Uint8Array(64 + tc.length);
      signed.set(sig.subarray(10));
      signed.set(tc, 64);
      const okGlobal = await crypto.subtle.verify({ name: "Ed25519" }, key, globalSig, signed);
      return okData && okGlobal;
    } catch (e) {
      return false; // includes browsers without Ed25519 in WebCrypto
    }
  }

  // ------------------------------------------------------- quality gate --
  const ID = /^ZRW-INTEL-\d+$/;
  const EXT_ID = /^([a-p]{32}|\{[0-9a-fA-F-]{36}\}|[A-Za-z0-9_.-]+@[A-Za-z0-9_.-]+)$/;

  /** Browser-extension entries of a parsed feed, or null if the feed is unusable. */
  function browserEntries(feed) {
    if (!feed || feed.schema !== 1 || !/^\d{4}-\d{2}-\d{2}$/.test(feed.updated) || !Array.isArray(feed.entries)) return null;
    const out = [];
    for (const e of feed.entries) {
      if (e?.kind !== "browser_extension") continue;
      const ok = ID.test(e.id) && EXT_ID.test(e.name) && typeof e.description === "string" && e.description.trim().length >= 20
        && typeof e.reference === "string" && e.reference.startsWith("https://");
      if (!ok) return null; // one bad entry rejects the whole feed, as in the desktop app
      out.push({ id: e.id, extension_id: e.name, name: e.label || e.name, description: e.description, reference: e.reference });
    }
    return out;
  }

  /** Downloads and verifies the feed. Returns { updated, entries } or throws. */
  async function download() {
    const get = async (url) => {
      const r = await fetch(url, { cache: "no-store", credentials: "omit" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const buf = new Uint8Array(await r.arrayBuffer());
      if (buf.length > MAX_BYTES) throw new Error("feed too large");
      return buf;
    };
    const [data, sig] = await Promise.all([get(FEED_URL), get(`${FEED_URL}.sig`)]);
    if (!(await verify(data, new TextDecoder().decode(sig)))) throw new Error("signature check failed");
    const feed = JSON.parse(new TextDecoder().decode(data));
    const entries = browserEntries(feed);
    if (!entries) throw new Error("feed failed the quality gate");
    return { updated: feed.updated, entries };
  }

  globalThis.ZFeed = { blake2b512, verify, browserEntries, download, PUBKEY };
})();
