"use strict";

const api = globalThis.browser ?? globalThis.chrome;
const $ = (id) => document.getElementById(id);
const SITES = { origins: ["http://*/*", "https://*/*"] };

const ICONS = {
  ok: '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>',
  bad: '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg>',
  off: '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12h8"/></svg>',
};

// Static icon markup, parsed as SVG (never as HTML).
const svg = (markup) => document.importNode(new DOMParser().parseFromString(markup, "image/svg+xml").documentElement, true);

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function button(label, cls, onClick) {
  const b = el("button", "btn" + (cls ? " " + cls : ""), label);
  b.addEventListener("click", onClick);
  return b;
}

// ---------------------------------------------------------------- current page --
let tabId = null;

function setPage(kind, title, sub) {
  const ico = $("page-ico");
  ico.className = "ico " + kind;
  ico.replaceChildren(svg(ICONS[kind === "ok" ? "ok" : kind === "bad" ? "bad" : "off"]));
  $("page-title").textContent = title;
  $("page-sub").textContent = sub || "";
}

function showStatus(st) {
  const list = $("page-list");
  const actions = $("page-actions");
  list.replaceChildren();
  actions.replaceChildren();
  if (!st) {
    setPage("muted", "This page can't be checked", "Browser pages, the extension store and PDFs are off-limits to extensions.");
    return;
  }
  if (!st.enabled) {
    setPage("muted", "Shield is off", "Turn on the Prompt-Injection Shield below.");
    return;
  }
  if (!st.count) {
    setPage("ok", "No hidden AI instructions", "This page looks clean.");
    return;
  }
  setPage(st.neutralized ? "ok" : "bad",
    st.neutralized ? `${st.count} hidden AI instruction${st.count > 1 ? "s" : ""} neutralized` : `${st.count} hidden AI instruction${st.count > 1 ? "s" : ""} found`,
    st.neutralized ? "Removed from the page – AI assistants reading it no longer receive them." : "Don't let an AI browser or assistant act on this page.");
  for (const f of st.items) {
    const it = el("div", "item");
    it.append(el("div", "meta", `${f.where} · ${f.how}`), el("div", "snip", f.snippet));
    list.append(it);
  }
  if (st.neutralized) actions.append(button("Restore", "", () => send("shield:restore")));
  else actions.append(button("Neutralize", "primary", () => send("shield:neutralize")));
  actions.append(button("Show on page", "", () => send("shield:show")));
}

async function send(type) {
  try {
    showStatus(await api.tabs.sendMessage(tabId, { type }, { frameId: 0 }));
  } catch (e) {
    showStatus(null);
  }
}

// ---------------------------------------------------------------- settings --
async function initToggles() {
  const s = await api.storage.local.get(["shield", "autoNeutralize", "pasteGuard"]);
  for (const t of document.querySelectorAll(".toggle")) {
    const k = t.dataset.key;
    t.checked = k === "autoNeutralize" ? !!s[k] : s[k] !== false;
    t.addEventListener("change", async () => {
      await api.storage.local.set({ [k]: t.checked });
      if (k === "shield" || k === "autoNeutralize") setTimeout(() => send("shield:status"), 150);
    });
  }
}

// ---------------------------------------------------------------- extensions --
function showExt(r) {
  const body = $("ext-body");
  if (!r) return;
  body.replaceChildren();
  const when = new Date(r.checkedAt).toLocaleString();
  if (!r.found.length) {
    const row = el("div", "ext");
    const ico = el("div", "ico ok");
    ico.append(svg(ICONS.ok));
    const g = el("div", "grow");
    g.append(el("div", "t", "No known malicious AI extensions"), el("div", "s", `${r.scanned} installed extensions checked against ${r.known} known threats · ${when}`));
    row.append(ico, g);
    body.append(row);
    return;
  }
  body.append(el("div", "s", `${r.found.length} known malicious extension${r.found.length > 1 ? "s" : ""} installed. Remove ${r.found.length > 1 ? "them" : "it"} now, then change the passwords of sites you used with ${r.found.length > 1 ? "them" : "it"}.`));
  for (const f of r.found) {
    const row = el("div", "ext");
    const ico = el("div", "ico bad");
    ico.append(svg(ICONS.bad));
    const g = el("div", "grow");
    const src = el("a", "s", "Source ↗");
    src.href = f.reference;
    src.target = "_blank";
    src.rel = "noopener";
    g.append(el("div", "t", f.installedName), el("div", "s", f.description), src);
    row.append(ico, g, button("Remove", "danger", async () => showExt(await api.runtime.sendMessage({ type: "ext:remove", id: f.extension_id }))));
    body.append(row);
  }
}

async function checkExtensions() {
  // The permission prompt must come straight from the click.
  const ok = await api.permissions.request({ permissions: ["management"] });
  if (!ok) return;
  $("ext-check").disabled = true;
  showExt(await api.runtime.sendMessage({ type: "ext:check" }));
  $("ext-check").disabled = false;
  $("ext-check").textContent = "Check again";
}

// ---------------------------------------------------------------- start --
(async () => {
  initToggles();
  try {
    const db = await (await fetch(api.runtime.getURL("intel/extensions.json"))).json();
    $("ext-known").textContent = String(db.entries.length);
  } catch (e) { /* keep "known" */ }
  const { extCheck } = await api.storage.local.get("extCheck");
  if (extCheck) { showExt(extCheck); $("ext-check").textContent = "Check again"; }
  $("ext-check").addEventListener("click", checkExtensions);

  // Firefox lets people allow website access later; ask for it here.
  if (!(await api.permissions.contains(SITES))) {
    $("access").classList.remove("hidden");
    $("grant").addEventListener("click", async () => {
      if (await api.permissions.request(SITES)) $("access").classList.add("hidden");
    });
  }

  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id ?? null;
  if (tabId == null) showStatus(null);
  else send("shield:status");
})();
