// ZaRemba AI Watcher – background worker: toolbar badge, settings defaults and
// the check for known malicious AI extensions.
"use strict";

const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { shield: true, autoNeutralize: false, pasteGuard: true };
const RED = "#e11d48";
const GREEN = "#059669";

let intel = null;
async function loadIntel() {
  if (!intel) intel = await (await fetch(api.runtime.getURL("intel/extensions.json"))).json();
  return intel;
}

api.runtime.onInstalled.addListener(async () => {
  const cur = await api.storage.local.get(Object.keys(DEFAULTS));
  const missing = {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (cur[k] === undefined) missing[k] = v;
  if (Object.keys(missing).length) await api.storage.local.set(missing);
  checkExtensions();
});

api.runtime.onMessage.addListener((msg, sender) => {
  const tabId = sender.tab?.id;
  if (msg?.type === "shield:count" && tabId != null) {
    const n = msg.count || 0;
    api.action.setBadgeText({ tabId, text: n ? String(n) : "" });
    api.action.setBadgeBackgroundColor({ tabId, color: msg.neutralized ? GREEN : RED });
  }
});

// ------------------------------------------------- malicious AI extensions --
// Needs the optional "management" permission, which the user grants from the
// popup. Without it this does nothing.
async function checkExtensions() {
  const has = await api.permissions.contains({ permissions: ["management"] });
  if (!has || !api.management) return null;
  const db = await loadIntel();
  const byId = new Map(db.entries.map((e) => [e.extension_id, e]));
  const installed = await api.management.getAll();
  const found = installed
    .filter((x) => byId.has(x.id))
    .map((x) => ({ ...byId.get(x.id), installedName: x.name, enabled: x.enabled }));
  const result = { checkedAt: Date.now(), scanned: installed.length, known: db.entries.length, found };
  await api.storage.local.set({ extCheck: result });
  await api.action.setBadgeText({ text: found.length ? "!" : "" });
  if (found.length) await api.action.setBadgeBackgroundColor({ color: RED });
  return result;
}

api.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "ext:check") {
    checkExtensions().then(reply);
    return true;
  }
  if (msg?.type === "ext:remove" && api.management?.uninstall) {
    // Chrome and Firefox show their own confirmation dialog.
    api.management.uninstall(msg.id, { showConfirmDialog: true }).then(() => checkExtensions()).then(reply, () => checkExtensions().then(reply));
    return true;
  }
  return false;
});

api.runtime.onStartup?.addListener(checkExtensions);
api.permissions.onAdded?.addListener(checkExtensions);
api.management?.onInstalled?.addListener(checkExtensions);
