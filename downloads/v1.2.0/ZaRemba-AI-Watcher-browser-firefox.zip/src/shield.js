// ZaRemba Prompt-Injection Shield – content script for every page.
//
// Looks for text that a person cannot see but an AI assistant reading the page
// would: hidden elements, tiny or invisible text, off-screen text, HTML
// comments, image alt/title text and invisible Unicode "tag" characters.
// Only such hidden text that also scores as an injection is reported.
// Neutralizing removes it from the page so AI tools that read the page no
// longer receive it; the user can restore it.
"use strict";

(() => {
  if (window.__zrwShield) return;
  window.__zrwShield = true;

  const api = globalThis.browser ?? globalThis.chrome;
  // Static icon markup, parsed as SVG (never as HTML).
  const svg = (markup) => document.importNode(new DOMParser().parseFromString(markup, "image/svg+xml").documentElement, true);
  const Z = globalThis.ZRW;
  const MAX_TEXT_NODES = 20000;
  const ATTRS = ["alt", "title", "aria-label", "aria-description", "placeholder", "data-prompt", "data-instructions"];

  let settings = { shield: true, autoNeutralize: false };
  let findings = []; // { id, where, how, snippet, reasons, undo }
  let neutralized = false;
  let banner = null;
  let dismissed = false;
  let nextId = 1;
  const seen = new WeakSet();

  // ------------------------------------------------------------ visibility --
  function parseColor(c) {
    const m = /rgba?\(([^)]+)\)/.exec(c || "");
    if (!m) return null;
    const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number);
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }

  function backgroundOf(el) {
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
      const c = parseColor(getComputedStyle(e).backgroundColor);
      if (c && c.a > 0.9) return c;
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  }

  /** Why `el` is invisible to a person, or "" if it is visible. */
  function hiddenReason(el) {
    let opacity = 1;
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
      const s = getComputedStyle(e);
      if (s.display === "none") return "hidden element";
      if (s.visibility === "hidden" || s.visibility === "collapse") return "hidden element";
      opacity *= parseFloat(s.opacity || "1");
      if (opacity < 0.05) return "transparent text";
      if (s.clipPath && /inset\(\s*(?:50%|100%)/.test(s.clipPath)) return "clipped away";
      if (s.clip && /rect\(\s*0(?:px)?[,\s]+0(?:px)?[,\s]+0(?:px)?[,\s]+0(?:px)?\s*\)/.test(s.clip)) return "clipped away";
      if (e.hasAttribute("hidden")) return "hidden element";
    }
    const s = getComputedStyle(el);
    if (parseFloat(s.fontSize) < 4) return "tiny text";
    const rect = el.getBoundingClientRect();
    if ((rect.width < 2 || rect.height < 2) && (s.overflow === "hidden" || s.overflowX === "hidden")) return "zero-size box";
    const docW = Math.max(document.documentElement.scrollWidth, innerWidth);
    const docH = Math.max(document.documentElement.scrollHeight, innerHeight);
    const left = rect.left + scrollX, top = rect.top + scrollY;
    if (left + rect.width < -50 || top + rect.height < -50 || left > docW + 50 || top > docH + 50) return "moved off-screen";
    const fg = parseColor(s.color);
    if (fg) {
      if (fg.a < 0.05) return "transparent text";
      const bg = backgroundOf(el);
      const d = Math.abs(fg.r - bg.r) + Math.abs(fg.g - bg.g) + Math.abs(fg.b - bg.b);
      if (d < 18) return "text in background colour";
    }
    return "";
  }

  // ---------------------------------------------------------------- scanning --
  function snippet(t) {
    const s = t.replace(/\s+/g, " ").trim();
    return s.length > 180 ? s.slice(0, 177) + "…" : s;
  }

  function add(where, how, text, reasons, undo) {
    findings.push({ id: nextId++, where, how, snippet: snippet(text), reasons, undo, active: false });
  }

  function scanTextNodes(rootNode) {
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT);
    let n = 0;
    // Group text by parent element: hidden payloads are often split over several nodes.
    const byParent = new Map();
    for (let node = walker.nextNode(); node && n < MAX_TEXT_NODES; node = walker.nextNode(), n++) {
      const p = node.parentElement;
      if (!p || seen.has(node)) continue;
      const tag = p.tagName;
      if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" || tag === "TEMPLATE" || p.closest("#zaremba-shield-host")) continue;
      const text = node.nodeValue;
      if (!text || text.trim().length < 3) continue;
      // Invisible tag characters are a finding on their own.
      for (const msg of Z.decodeTagSmuggling(text)) {
        seen.add(node);
        const original = node.nodeValue;
        add("invisible characters", "hidden Unicode tag characters", msg, ["contains an invisible message"], () => {
          node.nodeValue = original;
        });
        findings[findings.length - 1].apply = () => { node.nodeValue = original.replace(/(?:\uDB40[\uDC00-\uDC7F])+/g, ""); };
      }
      if (!byParent.has(p)) byParent.set(p, []);
      byParent.get(p).push(node);
    }
    for (const [p, nodes] of byParent) {
      const text = nodes.map((x) => x.nodeValue).join(" ");
      if (text.trim().length < 12) continue;
      // Cheap text check first; layout is only consulted for suspicious text.
      const sc = Z.injectionScore(text);
      if (sc.score < Z.INJECTION_THRESHOLD) continue;
      const how = hiddenReason(p);
      if (!how) continue;
      nodes.forEach((x) => seen.add(x));
      const originals = nodes.map((x) => x.nodeValue);
      add(describe(p), how, text, sc.reasons, () => nodes.forEach((x, i) => { x.nodeValue = originals[i]; }));
      findings[findings.length - 1].apply = () => nodes.forEach((x) => { x.nodeValue = ""; });
    }
  }

  function scanComments(rootNode) {
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_COMMENT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      if (seen.has(node)) continue;
      const text = node.nodeValue || "";
      const sc = Z.injectionScore(text);
      if (sc.score < Z.INJECTION_THRESHOLD) continue;
      seen.add(node);
      const original = text;
      add("HTML comment", "hidden in the page source", text, sc.reasons, () => { node.nodeValue = original; });
      findings[findings.length - 1].apply = () => { node.nodeValue = ""; };
    }
  }

  function scanAttributes(rootNode) {
    const sel = ATTRS.map((a) => `[${a}]`).join(",");
    for (const el of rootNode.querySelectorAll(sel)) {
      for (const a of ATTRS) {
        const v = el.getAttribute(a);
        if (!v || v.length < 12) continue;
        const key = el.__zrwAttrs || (el.__zrwAttrs = new Set());
        if (key.has(a)) continue;
        const sc = Z.injectionScore(v);
        if (sc.score < Z.INJECTION_THRESHOLD) continue;
        key.add(a);
        add(`${a} text of ${describe(el)}`, "not shown on the page", v, sc.reasons, () => el.setAttribute(a, v));
        findings[findings.length - 1].apply = () => el.removeAttribute(a);
      }
    }
  }

  function describe(el) {
    const t = el.tagName.toLowerCase();
    if (t === "img") return "image";
    if (t === "a") return "link";
    return `<${t}> element`;
  }

  function scan() {
    if (!settings.shield || !document.body) return;
    const before = findings.length;
    try {
      scanTextNodes(document.body);
      scanComments(document.documentElement);
      scanAttributes(document.body);
    } catch (e) {
      // A page may block style access in odd frames; never break the page.
    }
    if (findings.length !== before) {
      if (settings.autoNeutralize || neutralized) neutralize();
      report();
      render();
    }
  }

  // ---------------------------------------------------------------- actions --
  function neutralize() {
    for (const f of findings) if (!f.active) { f.apply(); f.active = true; }
    neutralized = true;
    report();
    render();
  }

  function restore() {
    for (const f of findings) if (f.active) { f.undo(); f.active = false; }
    neutralized = false;
    report();
    render();
  }

  function status() {
    return {
      enabled: settings.shield,
      count: findings.length,
      neutralized: findings.length > 0 && findings.every((f) => f.active),
      items: findings.map(({ where, how, snippet, reasons, active }) => ({ where, how, snippet, reasons, active })),
    };
  }

  function report() {
    if (window.top !== window) return;
    try { api.runtime.sendMessage({ type: "shield:count", count: findings.length, neutralized: status().neutralized }); } catch (e) { /* extension reloaded */ }
  }

  // ---------------------------------------------------------------- banner --
  const CSS = `
    :host { all: initial; }
    .card { position: fixed; right: 18px; bottom: 18px; z-index: 2147483647; width: 360px; max-width: calc(100vw - 36px);
      font: 13px/1.5 "Inter", -apple-system, "Segoe UI", system-ui, sans-serif; color: #e8eef8;
      background: #0d1420; border: 1px solid rgba(251,113,133,.35); border-radius: 14px;
      box-shadow: 0 18px 48px -12px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.02) inset; overflow: hidden;
      animation: in .28s cubic-bezier(.2,.8,.2,1); }
    .card.ok { border-color: rgba(52,211,153,.35); }
    @keyframes in { from { transform: translateY(12px); opacity: 0; } }
    .head { display: flex; gap: 10px; align-items: flex-start; padding: 14px 14px 10px; }
    .ico { flex: none; width: 30px; height: 30px; border-radius: 9px; display: grid; place-items: center; background: rgba(251,113,133,.13); color: #fb7185; }
    .ok .ico { background: rgba(52,211,153,.12); color: #34d399; }
    .t { font-weight: 600; font-size: 13.5px; }
    .s { color: #a9b6ca; font-size: 12.5px; margin-top: 2px; }
    .x { margin-left: auto; background: none; border: 0; color: #6f7f97; cursor: pointer; font-size: 18px; line-height: 1; padding: 2px 4px; }
    .x:hover { color: #e8eef8; }
    .list { margin: 0 14px; max-height: 180px; overflow: auto; display: none; }
    .open .list { display: block; }
    .item { border-top: 1px solid rgba(148,170,200,.1); padding: 8px 0; }
    .meta { color: #6f7f97; font-size: 11.5px; }
    .snip { font: 11.5px/1.45 "JetBrains Mono", ui-monospace, Consolas, monospace; color: #fda4af; word-break: break-word; margin-top: 3px; }
    .row { display: flex; gap: 8px; padding: 10px 14px 14px; align-items: center; }
    button.b { font: 600 12.5px "Inter", system-ui, sans-serif; border-radius: 8px; padding: 7px 12px; cursor: pointer; border: 1px solid rgba(148,170,200,.18); background: #162235; color: #e8eef8; }
    button.b:hover { border-color: rgba(148,170,200,.35); }
    button.p { background: linear-gradient(135deg, #22d3ee, #3b82f6); border: 0; color: #04121a; }
    .brand { margin-left: auto; color: #6f7f97; font-size: 11px; }`;

  const ICON_ALERT = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg>';
  const ICON_OK = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>';

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function render() {
    if (window.top !== window || dismissed || !findings.length) return;
    if (!banner) {
      const host = el("div");
      host.id = "zaremba-shield-host";
      const sh = host.attachShadow({ mode: "closed" });
      const style = el("style");
      style.textContent = CSS;
      const card = el("div", "card");
      sh.append(style, card);
      (document.body || document.documentElement).appendChild(host);
      banner = { host, card };
    }
    const { card } = banner;
    const st = status();
    const n = st.count;
    card.className = "card" + (st.neutralized ? " ok" : "") + (card.classList.contains("open") ? " open" : "");
    card.replaceChildren();

    const head = el("div", "head");
    const ico = el("div", "ico");
    ico.append(svg(st.neutralized ? ICON_OK : ICON_ALERT));
    const txt = el("div");
    txt.append(
      el("div", "t", st.neutralized ? `Hidden AI instructions neutralized (${n})` : `Hidden AI instructions on this page (${n})`),
      el("div", "s", st.neutralized
        ? "Removed from the page, so AI assistants reading it no longer receive them."
        : "Text you cannot see tries to give orders to AI assistants. Don't let an AI browser or assistant act on this page."),
    );
    const x = el("button", "x", "×");
    x.title = "Hide until next visit";
    x.addEventListener("click", () => { dismissed = true; banner.host.remove(); banner = null; });
    head.append(ico, txt, x);

    const list = el("div", "list");
    for (const f of st.items) {
      const it = el("div", "item");
      it.append(el("div", "meta", `${f.where} · ${f.how} · ${f.reasons.join("; ")}`), el("div", "snip", f.snippet));
      list.append(it);
    }

    const row = el("div", "row");
    if (!st.neutralized) {
      const b = el("button", "b p", "Neutralize");
      b.addEventListener("click", neutralize);
      row.append(b);
    } else {
      const b = el("button", "b", "Restore");
      b.addEventListener("click", restore);
      row.append(b);
    }
    const d = el("button", "b", card.classList.contains("open") ? "Hide details" : "Details");
    d.addEventListener("click", () => { card.classList.toggle("open"); render(); });
    row.append(d, el("span", "brand", "ZaRemba AI Watcher"));
    card.append(head, list, row);
  }

  // ---------------------------------------------------------------- wiring --
  let timer = null;
  const schedule = (ms) => { clearTimeout(timer); timer = setTimeout(scan, ms); };

  api.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (window.top !== window) return;
    if (msg?.type === "shield:status") reply(status());
    else if (msg?.type === "shield:neutralize") { neutralize(); reply(status()); }
    else if (msg?.type === "shield:restore") { restore(); reply(status()); }
    else if (msg?.type === "shield:show") { dismissed = false; render(); reply(status()); }
  });

  api.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.shield) settings.shield = ch.shield.newValue !== false;
    if (ch.autoNeutralize) settings.autoNeutralize = !!ch.autoNeutralize.newValue;
    if (settings.autoNeutralize && findings.some((f) => !f.active)) neutralize();
  });

  Promise.resolve(api.storage.local.get(["shield", "autoNeutralize"])).then((s) => {
    settings = { shield: s?.shield !== false, autoNeutralize: !!s?.autoNeutralize };
    if (!settings.shield) return;
    schedule(300);
    // Pages that load content later (chats, feeds, comments) are re-checked.
    let budget = 60;
    new MutationObserver(() => { if (budget-- > 0) schedule(1200); }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  });
})();
