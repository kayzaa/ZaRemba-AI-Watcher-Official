// ZaRemba Secret Paste Guard – content script for AI chat sites.
//
// Checks pasted and dropped text for API keys, private keys and passwords
// before the chat receives it. Everything is checked locally; nothing is sent
// anywhere. The user decides: paste without the secrets, paste anyway, cancel.
"use strict";

(() => {
  if (window.__zrwPasteGuard) return;
  window.__zrwPasteGuard = true;

  const api = globalThis.browser ?? globalThis.chrome;
  // Static icon markup, parsed as SVG (never as HTML).
  const svg = (markup) => document.importNode(new DOMParser().parseFromString(markup, "image/svg+xml").documentElement, true);
  const Z = globalThis.ZRW;
  let enabled = true;
  const ours = new WeakSet(); // paste events we re-dispatch ourselves

  Promise.resolve(api.storage.local.get(["pasteGuard"])).then((s) => { enabled = s?.pasteGuard !== false; });
  api.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.pasteGuard) enabled = ch.pasteGuard.newValue !== false;
  });

  function isEditable(t) {
    return t && (t.isContentEditable || t.tagName === "TEXTAREA" || (t.tagName === "INPUT" && /^(?:text|search|url|email|)$/i.test(t.type || "")));
  }

  /** Inserts `text` where the user pasted, the way the chat app expects. */
  function insert(target, text) {
    target.focus();
    try {
      const dt = new DataTransfer();
      dt.setData("text/plain", text);
      const ev = new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
      ours.add(ev);
      target.dispatchEvent(ev);
      if (ev.defaultPrevented) return; // the chat's editor handled it
    } catch (e) { /* fall through */ }
    // Plain text fields: insert like typing (keeps undo history).
    if (!document.execCommand("insertText", false, text)) {
      if ("value" in target) {
        const s = target.selectionStart ?? target.value.length, e = target.selectionEnd ?? s;
        target.value = target.value.slice(0, s) + text + target.value.slice(e);
        target.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
  }

  function onPaste(e) {
    if (!enabled || ours.has(e) || !isEditable(e.target)) return;
    const text = e.clipboardData?.getData("text/plain") || "";
    if (text.length < 8) return;
    const hits = Z.findSecrets(text);
    if (!hits.length) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const target = e.target;
    ask(hits, (choice) => {
      if (choice === "clean") insert(target, Z.redactSecrets(text));
      else if (choice === "anyway") insert(target, text);
      else target.focus();
    });
  }

  function onDrop(e) {
    if (!enabled || !isEditable(e.target)) return;
    const text = e.dataTransfer?.getData("text/plain") || "";
    const hits = text.length >= 8 ? Z.findSecrets(text) : [];
    if (!hits.length) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    const target = e.target;
    ask(hits, (choice) => {
      if (choice === "clean") insert(target, Z.redactSecrets(text));
      else if (choice === "anyway") insert(target, text);
    });
  }

  window.addEventListener("paste", onPaste, true);
  window.addEventListener("drop", onDrop, true);

  // ---------------------------------------------------------------- dialog --
  const CSS = `
    :host { all: initial; }
    .veil { position: fixed; inset: 0; z-index: 2147483647; background: rgba(3,6,12,.62); backdrop-filter: blur(3px);
      display: grid; place-items: center; animation: f .18s ease; }
    @keyframes f { from { opacity: 0; } }
    .box { width: 440px; max-width: calc(100vw - 32px); background: #0d1420; color: #e8eef8; border-radius: 16px;
      border: 1px solid rgba(251,191,36,.35); box-shadow: 0 24px 64px -16px rgba(0,0,0,.75);
      font: 13.5px/1.55 "Inter", -apple-system, "Segoe UI", system-ui, sans-serif; overflow: hidden;
      animation: u .26s cubic-bezier(.2,.8,.2,1); }
    @keyframes u { from { transform: translateY(10px) scale(.98); } }
    .head { display: flex; gap: 12px; padding: 18px 18px 6px; }
    .ico { flex: none; width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: rgba(251,191,36,.12); color: #fbbf24; }
    .t { font-weight: 650; font-size: 15px; }
    .s { color: #a9b6ca; margin-top: 3px; }
    .types { margin: 10px 18px 0; display: flex; flex-wrap: wrap; gap: 6px; }
    .pill { font-size: 12px; font-weight: 600; color: #fbbf24; background: rgba(251,191,36,.12); border-radius: 99px; padding: 3px 10px; }
    .note { margin: 12px 18px 0; color: #6f7f97; font-size: 12px; }
    .row { display: flex; gap: 8px; padding: 16px 18px 18px; justify-content: flex-end; flex-wrap: wrap; }
    button { font: 600 13px "Inter", system-ui, sans-serif; border-radius: 9px; padding: 8px 14px; cursor: pointer;
      border: 1px solid rgba(148,170,200,.18); background: #162235; color: #e8eef8; }
    button:hover { border-color: rgba(148,170,200,.35); }
    button.p { background: linear-gradient(135deg, #22d3ee, #3b82f6); border: 0; color: #04121a; }
    button.g { background: none; border-color: transparent; color: #a9b6ca; }`;
  const ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.3-9.3M17 6l3 3M14 9l2 2"/></svg>';

  function ask(hits, done) {
    const host = document.createElement("div");
    const sh = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    const veil = document.createElement("div");
    veil.className = "veil";
    const box = document.createElement("div");
    box.className = "box";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");

    const head = document.createElement("div");
    head.className = "head";
    const ico = document.createElement("div");
    ico.className = "ico";
    ico.append(svg(ICON));
    const txt = document.createElement("div");
    const t = document.createElement("div");
    t.className = "t";
    t.textContent = hits.length === 1 ? "You are about to paste a secret" : `You are about to paste ${hits.length} secrets`;
    const s = document.createElement("div");
    s.className = "s";
    s.textContent = "AI chats keep what you send, and it may be used to train models or be read by others. Anyone with this secret can use your account.";
    txt.append(t, s);
    head.append(ico, txt);

    const types = document.createElement("div");
    types.className = "types";
    for (const ty of new Set(hits.map((h) => h.type))) {
      const p = document.createElement("span");
      p.className = "pill";
      p.textContent = ty;
      types.append(p);
    }
    const note = document.createElement("div");
    note.className = "note";
    note.textContent = "Checked on your device by ZaRemba AI Watcher. Nothing was sent.";

    const row = document.createElement("div");
    row.className = "row";
    const finish = (c) => { host.remove(); document.removeEventListener("keydown", key, true); done(c); };
    const mk = (label, cls, c) => { const b = document.createElement("button"); b.textContent = label; if (cls) b.className = cls; b.addEventListener("click", () => finish(c)); return b; };
    const cancel = mk("Cancel", "g", "cancel");
    const anyway = mk("Paste anyway", "", "anyway");
    const clean = mk("Paste without secrets", "p", "clean");
    row.append(cancel, anyway, clean);
    const key = (e) => { if (e.key === "Escape") { e.stopPropagation(); finish("cancel"); } };
    document.addEventListener("keydown", key, true);
    veil.addEventListener("click", (e) => { if (e.target === veil) finish("cancel"); });

    box.append(head, types, note, row);
    veil.append(box);
    sh.append(style, veil);
    document.documentElement.appendChild(host);
    clean.focus();
  }
})();
