// ZaRemba AI Watcher – detection logic shared by the content scripts.
//
// Everything here is pure text analysis: no DOM, no network. It runs in the
// page's content-script world and in Node for the unit tests.
"use strict";

(function (root) {
  // ---------------------------------------------------------------- prompt injection --
  // A text is an injection candidate when it matches several *different* signal
  // groups. One group alone (an article that mentions "system prompt") is not
  // enough. The shield only reports text the user cannot see, so a visible
  // article about prompt injection is never flagged.
  const AI = String.raw`(?:ai|a\.i\.|assistant|llm|language model|agent|chat ?bot|claude|chat ?gpt|gpt|gemini|copilot|perplexity|comet|atlas|grok|deepseek|model)`;
  const GROUPS = [
    {
      id: "override",
      label: "tries to override the AI's instructions",
      weight: 3,
      res: [
        /\b(?:ignore|disregard|forget|override|bypass|skip)\s+(?:all\s+|any\s+|the\s+|your\s+|of\s+)*(?:previous|prior|above|earlier|preceding|original|existing|system|safety|other)\s+(?:instructions?|prompts?|messages?|rules|guidelines|directions|context)/i,
        /\b(?:new|updated|real|actual|true|hidden|secret)\s+(?:system\s+)?instructions?\s*[:\-]/i,
        /\byou\s+are\s+now\s+(?:in\s+)?(?:developer|dan|jailbreak|unrestricted|admin|god)\b/i,
        /\b(?:do\s+not|don'?t|never)\s+(?:tell|inform|alert|warn|mention\s+(?:this\s+)?to|reveal\s+(?:this\s+)?to|show)\s+(?:the\s+)?(?:user|human|owner)/i,
        /\bwithout\s+(?:telling|informing|asking|alerting|notifying)\s+(?:the\s+)?(?:user|human|owner)/i,
      ],
    },
    {
      id: "addressed",
      label: "speaks directly to an AI assistant",
      weight: 2,
      res: [
        new RegExp(String.raw`\b(?:attention|note|message|instructions?|important|notice|reminder)\s+(?:to|for)\s+(?:the\s+|any\s+|all\s+)?${AI}s?\b`, "i"),
        new RegExp(String.raw`\bif\s+you\s+are\s+(?:an?\s+)?${AI}\b`, "i"),
        new RegExp(String.raw`\b(?:dear|hey|hi|hello)\s+${AI}\b`, "i"),
        new RegExp(String.raw`\b${AI}s?\s+(?:reading|summari[sz]ing|browsing|processing|visiting)\s+this\b`, "i"),
        /\bas\s+an?\s+(?:ai|language model|assistant|agent)\s*(?:,|you\s+must|you\s+should)/i,
      ],
    },
    {
      id: "action",
      label: "asks for a risky action (send data, open links, change ratings)",
      weight: 2,
      res: [
        /\b(?:send|forward|e-?mail|post|upload|exfiltrate|submit|share|copy|paste|leak|transmit)\b[^.!?\n]{0,60}\b(?:passwords?|credentials?|cookies?|tokens?|api[\s_-]?keys?|e-?mails?|inbox|otp|one[\s-]time|codes?|private|wallet|seed|recovery phrase|history|conversations?|chats?|personal data|address|phone)\b/i,
        /\b(?:open|navigate\s+to|visit|go\s+to|load|fetch|click)\s+(?:the\s+(?:url|link|page)\s+)?(?:https?:\/\/|www\.)/i,
        /\b(?:read|open|check|access|search)\s+(?:the\s+)?(?:user'?s?\s+|their\s+|my\s+)?(?:inbox|gmail|e-?mails?|messages|password manager|bank)/i,
        /\b(?:log\s?in|sign\s?in|enter\s+(?:the\s+)?(?:password|credentials))\s+(?:to|at|on)\s+/i,
        /\b(?:rate|describe|summari[sz]e|recommend|rank|evaluate|review)\s+(?:this|the)\s+(?:page|site|website|product|company|candidate|applicant|resume|cv|paper|submission|article)\s+(?:as|positively|highly|favou?rably|above)/i,
        /\b(?:hire|accept|approve|recommend)\s+this\s+(?:candidate|applicant|paper|submission|person)\b/i,
        /\b(?:give|leave|write)\s+(?:this|a|an)\s+(?:positive|excellent|glowing|5[-\s]star|five[-\s]star)\s+(?:review|rating|assessment)/i,
        /\b(?:run|execute)\s+(?:this|the following)\s+(?:command|code|script)\b/i,
        /\b(?:transfer|send|pay)\s+(?:\$|€|£)?\s?\d[\d.,]*\s*(?:usd|eur|btc|eth|usdt|dollars?|euros?)?\s+to\b/i,
      ],
    },
    {
      id: "markup",
      label: "contains chat-model control markers",
      weight: 2,
      res: [
        /<\|im_start\|>|<\|im_end\|>|<\|system\|>|<\|endoftext\|>/i,
        /\[\/?INST\]|<<\/?SYS>>/,
        /(?:^|\n)\s*#{2,}\s*(?:system|instructions?)\b/i,
        /<\/?(?:system|instructions?|admin|developer)(?:\s[^>]*)?>/i,
        /\b(?:begin|end)\s+(?:system\s+prompt|instructions)\b/i,
      ],
    },
  ];

  /** Scores `text` for prompt-injection signals. */
  function injectionScore(text) {
    const t = String(text || "").slice(0, 20000);
    let score = 0;
    const reasons = [];
    for (const g of GROUPS) {
      if (g.res.some((re) => re.test(t))) {
        score += g.weight;
        reasons.push(g.label);
      }
    }
    return { score, reasons };
  }

  /** Threshold for hidden text: an override attempt alone, or two other groups. */
  const INJECTION_THRESHOLD = 3;

  function isInjection(text) {
    return injectionScore(text).score >= INJECTION_THRESHOLD;
  }

  // Unicode "tag" characters (U+E0000–U+E007F) are invisible and can carry a
  // complete hidden message ("ASCII smuggling"). Normal text never uses them,
  // except as part of a few flag emoji sequences, which are short.
  const TAG_RUN = /(?:\uDB40[\uDC00-\uDC7F]){8,}/g;

  /** Returns the hidden ASCII messages smuggled in Unicode tag characters. */
  function decodeTagSmuggling(text) {
    const out = [];
    for (const m of String(text || "").matchAll(TAG_RUN)) {
      let s = "";
      for (const ch of m[0]) s += String.fromCharCode(ch.codePointAt(0) - 0xe0000);
      out.push(s);
    }
    return out;
  }

  // ---------------------------------------------------------------- secrets --
  // Most specific first: an Anthropic key also starts with "sk-".
  const SECRET_PATTERNS = [
    ["Private key", /-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----[\s\S]*?-----END (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----/g],
    ["Anthropic API key", /\bsk-ant-[A-Za-z0-9_\-]{20,}/g],
    ["OpenRouter API key", /\bsk-or-v1-[A-Za-z0-9]{32,}/g],
    ["OpenAI API key", /\bsk-(?:proj-|svcacct-|admin-)?[A-Za-z0-9_\-]{20,}/g],
    ["Google API key", /\bAIza[0-9A-Za-z_\-]{35}/g],
    ["Hugging Face token", /\bhf_[A-Za-z0-9]{30,}/g],
    ["GitHub token", /\b(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{50,})/g],
    ["AWS access key", /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g],
    ["Stripe secret key", /\b(?:sk|rk)_live_[0-9A-Za-z]{20,}/g],
    ["Slack token", /\bxox[abposr]-[0-9A-Za-z-]{10,}/g],
    ["Database URL with password", /\b(?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|redis|rediss|amqp):\/\/[^\s:@\/]+:[^\s@\/]+@[^\s]+/g],
  ];
  // "password = hunter2", "API_KEY: abc…" – only the value is replaced.
  const GENERIC = /\b(password|passwd|pwd|secret|client[_-]?secret|token|api[_-]?key|access[_-]?key|private[_-]?key)(\s*[:=]\s*)("[^"\n]{4,}"|'[^'\n]{4,}'|[^\s"',;]{6,})/gi;

  /** Finds secrets in `text`. Returns [{type, start, end}] without the values. */
  function findSecrets(text) {
    const t = String(text || "");
    const hits = [];
    const taken = [];
    const free = (s, e) => !taken.some(([a, b]) => s < b && a < e);
    for (const [type, re] of SECRET_PATTERNS) {
      re.lastIndex = 0;
      for (const m of t.matchAll(re)) {
        const s = m.index, e = m.index + m[0].length;
        if (free(s, e)) { taken.push([s, e]); hits.push({ type, start: s, end: e }); }
      }
    }
    GENERIC.lastIndex = 0;
    for (const m of t.matchAll(GENERIC)) {
      const s = m.index + m[1].length + m[2].length, e = m.index + m[0].length;
      const value = m[3].replace(/^["']|["']$/g, "");
      // Placeholders like "password: <your password>" or "token=xxxxxx" are not secrets.
      if (/^(?:<.*>|\$\{.*\}|\{\{.*\}\}|x+|\*+|\.+|your[_-].*|changeme|example|placeholder|null|none|true|false|undefined|redacted)$/i.test(value)) continue;
      if (free(s, e)) { taken.push([s, e]); hits.push({ type: "Password or token", start: s, end: e }); }
    }
    return hits.sort((a, b) => a.start - b.start);
  }

  /** Replaces every secret in `text` with a short placeholder. */
  function redactSecrets(text) {
    const t = String(text || "");
    let out = "", at = 0;
    for (const h of findSecrets(t)) {
      out += t.slice(at, h.start) + `[REDACTED ${h.type}]`;
      at = h.end;
    }
    return out + t.slice(at);
  }

  /** Short summary like "OpenAI API key, Private key" (each type once). */
  function secretSummary(hits) {
    return [...new Set(hits.map((h) => h.type))].join(", ");
  }

  const api = { injectionScore, isInjection, INJECTION_THRESHOLD, decodeTagSmuggling, findSecrets, redactSecrets, secretSummary };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ZRW = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
